<footer>
        <div class="column logo-address">
          <div class="footer-logo">
            <a href="">
              <img src="./img/logo/logo_png.png" alt="" />
            </a>
            <ul class="footer-list">
              <li>FPT Phố Trịnh Văn Bô, Xuân Phương, <br> Nam Từ Liêm, Hà Nội</li>
              <li>01224345465</li>
              <li>user@gmail.com</li>
            </ul>
          </div>
        </div>
        <!-- ---------------------------------- -->
        <div class="d-f jf-b " style="width:57%">
          <div class="column2 logo-address">
            <div class="footer-logo2">
              <h3>Liên kết hữu ích</h3>
              <ul class="footer-list">
                <li>Về chúng tôi</li>
                <li>Liên hệ</li>
                <li>Chính sách bảo mật</li>
                <li>Chính sách đổi trả</li>
              </ul>
            </div>
          </div>
          <!-- ---------------------------------- -->
          <div class="column2 logo-address">
            <div class="footer-logo2">
              <h3>Đăng kí nhận thông tin mới nhất</h3>
              <ul class="footer-list">
                <li>
                  Nhập email của bạn để nhận thông tin khuyến mãi sớm nhất của
                  chúng tôi
                </li>
              </ul>
              <div class="search w-100">
                <form action="" class="d-f">
                  <input
                    style="width: 175px"
                    type="text"
                    class="input-search"
                    placeholder="Đăng kí"
                  />
                  <input
                    type="submit"
                    value="Đăng kí"
                    style="padding: 10px 15px"
                    class="search-btn"
                  />
                </form>
              </div>
              <div class="social d-f" style="margin-top: 20px; width: 100%">
                <a href="#"><i class="fa-brands fa-facebook-f"></i></a>
                <a href="#"><i class="fa-brands fa-twitter"></i></a>
                <a href="#"><i class="fa-brands fa-linkedin-in"></i></a>
                <a href="#"><i class="fa-brands fa-pinterest-p"></i></a>
              </div>
            </div>
          </div>
          <!-- ---------------------------------- -->
        </div>
      </footer>
    </div>



    
     <!-- ------------------loading chuột hamster ---------------------------- -->
     <div class="container1">
      <div
        aria-label="Orange and tan hamster running in a metal wheel"
        role="img"
        class="wheel-and-hamster"
      >
        <div class="wheel"></div>
        <div class="hamster">
          <div class="hamster__body">
            <div class="hamster__head">
              <div class="hamster__ear"></div>
              <div class="hamster__eye"></div>
              <div class="hamster__nose"></div>
            </div>
            <div class="hamster__limb hamster__limb--fr"></div>
            <div class="hamster__limb hamster__limb--fl"></div>
            <div class="hamster__limb hamster__limb--br"></div>
            <div class="hamster__limb hamster__limb--bl"></div>
            <div class="hamster__tail"></div>
          </div>
        </div>
        <div class="spoke"></div>
      </div>
    </div>
<?php
if(!isset($_GET['f'])){ ?>
  <script type="module" src="JavaScript/main.js"></script>

 <?php } ?>


    <script type="text/javascript" src="JavaScript/link.js"></script>
    <script type="text/javascript" src="JavaScript/header.js"></script>
    <script type="text/javascript" src="JavaScript/banner.js"></script>
    <script type="text/javascript" src="JavaScript/slide.js"></script>
  </body>
</html>