<div class="product-page-banner">
    <span class="product-page-banner_title">Trang chủ - Tin tức</span>
  </div>

    <div id="wrapper-tintuc" style="margin-top: 20px;">
        <div class="baiviet">
            <div class="noidung">
                <div class="image">
                    <img src="img/banner/tintuc-1.png" alt="">
                </div>
                <div class="content">
                    <div class="tieude">
                        <h2>Chương trình ưu đãi mua size L 14k</h2>
                    </div>
                    <div class="mota">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Distinctio nisi pariatur nam
                        eaque unde dolor quisquam ut sapiente, maxime sed?
                    </div>
                </div>
            </div>

            <div class="noidung">
                <div class="image">
                    <img src="img/banner/tintuc-2.png" alt="">
                </div>
                <div class="content">
                    <div class="tieude">
                        <h2>Lập team phá đảo loạt cửa hàng mới trà sữa quốc dân teaplus</h2>
                    </div>
                    <div class="mota">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Distinctio nisi pariatur nam
                        eaque unde dolor quisquam ut sapiente, maxime sed?
                    </div>
                </div>
            </div>

            <div class="noidung">
                <div class="image">
                    <img src="img/banner/tintuc-3.png" alt="">
                </div>
                <div class="content">
                    <div class="tieude">
                        <h2>Chương trình ưu đãi mua size L 14k</h2>
                    </div>
                    <div class="mota">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Distinctio nisi pariatur nam
                        eaque unde dolor quisquam ut sapiente, maxime sed?
                    </div>
                </div>
            </div>

            <div class="noidung">
                <div class="image">
                    <img src="img/banner/tintuc-4.jpg" alt="">
                </div>
                <div class="content">
                    <div class="tieude">
                        <h2>Chương trình ưu đãi mua size L 14k</h2>
                    </div>
                    <div class="mota">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Distinctio nisi pariatur nam
                        eaque unde dolor quisquam ut sapiente, maxime sed?
                    </div>
                </div>
            </div>

            <div class="noidung">
                <div class="image">
                    <img src="img/banner/tintuc-1.png" alt="">
                </div>
                <div class="content">
                    <div class="tieude">
                        <h2>Chương trình ưu đãi mua size L 14k</h2>
                    </div>
                    <div class="mota">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Distinctio nisi pariatur nam
                        eaque unde dolor quisquam ut sapiente, maxime sed?
                    </div>
                </div>
            </div>

        </div>
    </div>