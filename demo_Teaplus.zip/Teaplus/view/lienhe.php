<main class="w-100 d-f f-d al-c">
               <div class="product-page-banner">
                   <span class="product-page-banner_title">Trang chủ - Liên hệ</span>
              </div>

<div class="container-lienhe d-f jf-c">
    <div class="wrapper-lienhe">
        <div class="container-lienhe_left"></div>
        <div class="container-lienhe_right">
        <form action="index.php?act=lienhe&header=headerSecond" method="post" class="container-lienhe_right_form">
                <h1 class="container-lienhe_right_form_title">Liên hệ</h1>
                <ul class="container-lienhe_right_form_data">
                    <li>
                        <p>Họ và Tên
                        </p> <input name="hovaten" placeholder="Họ và Tên" class="container-lienhe_right_form_text" type="text" required></li>
                    </li>
                    <li>
                        <p>Địa chỉ</p> <input name="diachi" placeholder="Địa chỉ..." class="container-lienhe_right__form_text" type="text" required>
                    </li>
                    <li>
                        <p>Điện thoại
                        <p> <input name="dienthoai" placeholder="Điện thoại" class="container-lienhe_right_form_text" type="text" required>
                    </li>
                    <li>
                        <p>Email</p> <input name="email" placeholder="Email..." class="container-lienhe_right_form_text" type="email" required>
                    </li>
                    <li>
                        <p>Lời nhắn</p> <textarea name="loinhan" style="resize: none;" id="" cols="33" rows="2" required></textarea>
                    </li>
                </ul>
                <input style="width: 180px; height: 39px;" name="submit" type="submit" class="container-lienhe_right_form_bt" value="Gửi liên hệ">
                <input style="width: 180px; height: 39px;" type="reset" class="container-lienhe_right_form_bt" value="Soạn lại">
            </form>
        </div>
    </div>
</div>
<h1 class="title_product_new">Bản đồ </h1>
<div style="width: 100%"><iframe width="100%" height="400" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=Vi%E1%BB%87t%20Nam%20,%20Tr%E1%BB%8Bnh%20V%C4%83n%20B%C3%B4%20,%20Cao%20%C4%91%E1%BA%B3ng%20FPT%20Polytechnic+(My%20Business%20Name)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"><a href="https://www.maps.ie/distance-area-calculator.html">distance maps</a></iframe></div>
</main>